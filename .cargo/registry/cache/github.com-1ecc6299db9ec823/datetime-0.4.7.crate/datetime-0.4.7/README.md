# rust-datetime [![Build status](https://travis-ci.org/rust-datetime/datetime.svg?branch=master)](https://travis-ci.org/rust-datetime/datetime)

Date/time library for Rust! Very much a work in progress.

### [View the Rustdoc](https://docs.rs/datetime)
