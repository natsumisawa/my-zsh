# zoneinfo_compiled [![Build Status](https://travis-ci.org/rust-datetime/zoneinfo-compiled.svg?branch=master)](https://travis-ci.org/rust-datetime/zoneinfo-compiled)

This is a library for parsing compiled versions of the Olson zoneinfo database.

### [View the Rustdoc](http://datetime.rustdocs.org/zoneinfo-compiled/)
